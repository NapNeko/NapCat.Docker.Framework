# LiteLoaderQQNT

LiteLoaderQQNT 是 QQNT 的插件加载器，一般在 QQNT 的环境内简称为 LiteLoader。  
它可以让你自由地为 QQNT 添加各种插件，并实现例如美化主题、增加功能等各种功能。

详情查看 LiteLoaderQQNT 官网：https://liteloaderqqnt.github.io
